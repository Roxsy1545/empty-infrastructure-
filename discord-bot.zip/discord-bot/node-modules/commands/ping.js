const { SlashCommandBuilder } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('ping')
        .setDescription('Botun gecikmesini kontrol eder.'),
    async execute(interaction) {
        await interaction.reply(`Pong! Gecikme: ${client.ws.ping}ms`);
    },
};